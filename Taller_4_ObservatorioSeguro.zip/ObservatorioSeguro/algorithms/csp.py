"""Puntos 1–3. Retroceso, consistencia de arcos y heurísticas."""
from collections import deque
from models.csp import SearchTrace, copy_domains


def backtracking_search(csp, domains=None, select_variable=None,
                        order_values=None, trace=None):
    """Punto 1: retorna {tarea: franja} o None si no hay solución.

    Entradas: csp representa el problema; domains contiene los dominios vigentes,
    reducidos por AC-3 cuando corresponde.
    csp.variables contiene los identificadores de las tareas, en orden.
    domains es {tarea: [franjas enteras]}; assignment es {tarea: franja}.
    El bloque por completar define expand(assignment).

    Tips:
    - choose(csp, assignment, domains) retorna una tarea pendiente;
      ordered(csp, x, assignment, domains) retorna sus valores en orden.
    - consistent(x, valor, assignment) retorna si el candidato es compatible
      con la asignación parcial; es el comprobador suministrado para este bloque.
    - search(nueva_asignacion) es la llamada recursiva suministrada. Recibe
      una asignación independiente y retorna una solución completa o None.
    """
    trace = trace if trace is not None else SearchTrace(False)
    domains = copy_domains(csp.domains if domains is None else domains)
    choose = select_variable or (lambda p, a, d: next(x for x in p.variables if x not in a))
    ordering = order_values or (lambda p, x, a, d: list(d[x]))

    # Registra las decisiones y los cambios de la búsqueda.
    def snapshot(assignment):
        return {x: [assignment[x]] if x in assignment else list(domains[x])
                for x in csp.variables}

    def ordered(problem, variable, assignment, current_domains):
        values = ordering(problem, variable, assignment, current_domains)
        trace.record('select', f'Elegir {variable}. Orden de valores: {values}.',
                     assignment, snapshot(assignment) if trace.enabled else domains, variable)
        return values

    def consistent(variable, value, assignment):
        current = snapshot(assignment) if trace.enabled else domains
        trace.attempt(assignment, current, variable, value)
        valid = csp.consistent(variable, value, assignment)
        if valid and trace.enabled:
            child = {**assignment, variable: value}
            trace.record('assign', f'Asignar {variable} a la franja {value}.',
                         child, snapshot(child), variable, value)
        elif not valid:
            trace.record('reject', 'El valor entra en conflicto con una tarea asignada.',
                         assignment, current, variable, value)
        return valid

    def search(assignment):
        result = expand(assignment)
        if result is None and len(assignment) < len(csp.variables):
            trace.fail(assignment, snapshot(assignment) if trace.enabled else domains)
            if assignment and trace.enabled:
                variable = next(reversed(assignment))
                parent = {x: v for x, v in assignment.items() if x != variable}
                trace.restore(parent, snapshot(parent), variable)
        return result

    def expand(assignment):
        if len(assignment) == len(csp.variables):
            return assignment

        tarea = choose(csp, assignment, domains)

        for franja in ordered(csp, tarea, assignment, domains):
            if consistent(tarea, franja, assignment):
                nueva_asignacion = assignment.copy()
                nueva_asignacion[tarea] = franja

                resultado = search(nueva_asignacion)

                if resultado is not None:
                    return resultado

        return None

    return search({})


def revise(csp, x, y, domains):
    """Punto 2: revisa X→Y modificando domains[x].

    Retorna True únicamente si cambia ese dominio; False en caso contrario.

    Tips:
    - x e y son identificadores de tareas; domains[x] y domains[y] son listas.
    - csp.compatible(x, valor_x, y, valor_y) comprueba las restricciones
      entre ese par de tareas, respetando la dirección de las precedencias.
    - Si elimina elementos mientras recorre una lista, itere sobre una copia.
    """
    
    modificado = False

    for valor_x in domains[x].copy():
        tiene_soporte = False

        for valor_y in domains[y]:
            if csp.compatible(x, valor_x, y, valor_y):
                tiene_soporte = True
                break

        if not tiene_soporte:
            domains[x].remove(valor_x)
            modificado = True

    return modificado


def ac3(csp, domains):
    """Punto 2: reduce domains; retorna False si detecta un dominio vacío.

    Un retorno True indica consistencia de arcos, no garantiza una solución.

    Tips:
    - Cada arco es un par (x, y) de identificadores de tareas.
      csp.neighbors[x] contiene los vecinos de x.
    - revise(csp, x, y, domains) retorna si modificó domains[x].
    """
    queue = deque()

    for x in csp.variables:
        if not domains[x]:
            return False

        for y in csp.neighbors[x]:
            queue.append((x, y))

    while queue:
        x, y = queue.popleft()

        if revise(csp, x, y, domains):
            if not domains[x]:
                return False

            for z in csp.neighbors[x]:
                if z != y:
                    queue.append((z, x))

    return True


def select_unassigned_variable(csp, assignment, domains):
    """Punto 3: retorna el identificador de la variable elegida por MRV y grado.

    Tips:
    - csp.consistent(x, valor, assignment) comprueba si un candidato es
      compatible con la asignación parcial. Los dominios deben conservarse.
    - csp.neighbors[x] contiene sus vecinos; csp.variables conserva el orden
      original para los desempates.
    """
    mejor_variable = None
    mejor_mrv = float('inf')
    mejor_grado = -1

    for variable in csp.variables:
        if variable not in assignment:
            mrv = 0
            grado = 0

            for valor in domains[variable]:
                if csp.consistent(variable, valor, assignment):
                    mrv += 1

            for vecino in csp.neighbors[variable]:
                if vecino not in assignment:
                    grado += 1

            if mrv < mejor_mrv or (mrv == mejor_mrv and grado > mejor_grado):
                mejor_variable = variable
                mejor_mrv = mrv
                mejor_grado = grado

    return mejor_variable


def order_domain_values(csp, variable, assignment, domains):
    """Punto 3: retorna los valores compatibles ordenados por LCV.

    Retorne una lista nueva sin modificar domains y conserve el orden original
    en los empates.

    Tips:
    - Use valores de domains compatibles con assignment, tanto para los
      candidatos como para los vecinos pendientes; compruébelos con
      csp.consistent(x, valor, assignment).
    - csp.compatible(variable, valor, vecino, valor_vecino) comprueba cada par
      sin modificar los dominios.
    """
    candidatos = []

    for valor in domains[variable]:
        if csp.consistent(variable, valor, assignment):
            candidatos.append(valor)

    def valores_descartados(valor):
        descartados = 0

        for vecino in csp.neighbors[variable]:
            if vecino not in assignment:
                for valor_vecino in domains[vecino]:
                    if csp.consistent(vecino, valor_vecino, assignment):
                        if not csp.compatible(variable, valor, vecino, valor_vecino):
                            descartados += 1

        return descartados

    return sorted(candidatos, key=valores_descartados)
